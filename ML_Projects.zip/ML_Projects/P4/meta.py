from pydantic import BaseModel
class var_data(BaseModel):
    X1: float 
    X2: float 